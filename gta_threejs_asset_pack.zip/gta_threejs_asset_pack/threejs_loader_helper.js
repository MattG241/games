// Three.js GLB loader helper
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

export function loadAsset(scene, url, position = [0, 0, 0], scale = [1, 1, 1]) {
  const loader = new GLTFLoader();

  loader.load(
    url,
    (gltf) => {
      const asset = gltf.scene;
      asset.position.set(position[0], position[1], position[2]);
      asset.scale.set(scale[0], scale[1], scale[2]);

      asset.traverse((child) => {
        if (child.isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });

      scene.add(asset);
    },
    undefined,
    (error) => {
      console.error(`Failed to load asset: ${url}`, error);
    }
  );
}

// Example:
// loadAsset(scene, '/assets/city_traffic_light.glb', [4, 0, -2], [1, 1, 1]);