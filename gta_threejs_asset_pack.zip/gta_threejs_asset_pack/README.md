# GTA-style Three.js Asset Pack

This pack contains 10 low-poly `.glb` assets made for a browser-based Three.js city / open-world game.

## Assets

1. `low_poly_sports_car.glb`
2. `city_traffic_light.glb`
3. `concrete_road_barrier.glb`
4. `street_dumpster.glb`
5. `low_poly_palm_tree.glb`
6. `neon_shop_sign.glb`
7. `fire_hydrant.glb`
8. `wooden_loot_crate.glb`
9. `cash_pickup_bundle.glb`
10. `street_bench.glb`

## Three.js import example

```js
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const loader = new GLTFLoader();

loader.load('/assets/low_poly_sports_car.glb', (gltf) => {
  const car = gltf.scene;
  car.position.set(0, 0, 0);
  car.scale.set(1, 1, 1);
  scene.add(car);
});
```

## Notes

- These are lightweight low-poly props intended for quick use in web games.
- No copyrighted brands or logos are included.
- Each asset is a standalone `.glb` file.
- Best used with lighting, shadows, and a simple city environment.