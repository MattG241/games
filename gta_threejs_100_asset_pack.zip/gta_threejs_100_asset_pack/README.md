# GTA-style Three.js 100 Piece Asset Pack

This pack contains **100 lightweight low-poly `.glb` assets** for a browser-based open-world city / GTA-style Three.js HTML game.

## Included categories

- Vehicles
- Road props
- Road tiles
- City props
- Buildings
- Building props
- Environment props
- Environment tiles
- Collectibles
- Gameplay props
- Decorative props

## Import one asset

```js
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const loader = new GLTFLoader();

loader.load('/assets/vehicle_red_sports_car.glb', (gltf) => {
  const asset = gltf.scene;
  asset.position.set(0, 0, 0);
  asset.scale.set(1, 1, 1);
  scene.add(asset);
});
```

## Batch helper

Use `threejs_asset_loader.js` to load assets by filename from the manifest.

## Folder structure

```txt
gta_threejs_100_asset_pack/
  assets/
    100 .glb files
  manifest.json
  threejs_asset_loader.js
  README.md
```

## Notes

- These are intentionally lightweight for browser games.
- Add your own physics colliders using the `collision` field in `manifest.json`.
- Suggested use: clone assets, place with a level editor, or spawn from JSON.