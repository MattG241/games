import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const loader = new GLTFLoader();
const cache = new Map();

export async function loadGLB(url) {
  if (cache.has(url)) {
    return cache.get(url).clone(true);
  }

  const gltf = await new Promise((resolve, reject) => {
    loader.load(url, resolve, undefined, reject);
  });

  const scene = gltf.scene;
  scene.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = true;
      child.receiveShadow = true;
    }
  });

  cache.set(url, scene);
  return scene.clone(true);
}

export async function spawnAsset({
  scene,
  file,
  basePath = '/assets/',
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  scale = [1, 1, 1],
}) {
  const asset = await loadGLB(`${basePath}${file}`);

  asset.position.set(position[0], position[1], position[2]);
  asset.rotation.set(rotation[0], rotation[1], rotation[2]);
  asset.scale.set(scale[0], scale[1], scale[2]);

  scene.add(asset);
  return asset;
}

// Example:
// await spawnAsset({
//   scene,
//   file: 'vehicle_red_sports_car.glb',
//   position: [0, 0, 0],
//   scale: [1, 1, 1],
// });