# Asset Index

## building_props
- `building_gas_pump_red.glb`. Red gas pump
- `building_neon_sign_pink_blue.glb`. Pink blue neon sign
- `building_rollup_garage_door.glb`. Rollup garage door
- `building_rooftop_ac_unit.glb`. Rooftop AC unit
- `building_satellite_dish.glb`. Satellite dish
- `building_shop_awning_red.glb`. Red shop awning

## buildings
- `building_brick_shop.glb`. Brick shop building
- `building_garage.glb`. Garage building
- `building_neon_nightclub.glb`. Neon nightclub shell
- `building_service_station.glb`. Service station shop
- `building_small_apartment.glb`. Small apartment building
- `building_tall_office.glb`. Tall office building
- `building_warehouse.glb`. Warehouse building
- `building_white_corner_store.glb`. White corner store

## city_props
- `city_atm_machine.glb`. ATM machine
- `city_blue_dumpster.glb`. Blue dumpster
- `city_blue_ticket_machine.glb`. Blue ticket machine
- `city_bus_stop_shelter.glb`. Bus stop shelter
- `city_fire_hydrant_red.glb`. Red fire hydrant
- `city_green_dumpster.glb`. Green dumpster
- `city_mailbox_blue.glb`. Blue mailbox
- `city_newspaper_box.glb`. Newspaper box
- `city_oil_barrel_blue.glb`. Blue oil barrel
- `city_oil_barrel_red.glb`. Red oil barrel
- `city_parking_meter.glb`. Parking meter
- `city_red_phone_booth.glb`. Red phone booth
- `city_red_vending_machine.glb`. Red vending machine
- `city_reflective_bollard.glb`. Reflective bollard
- `city_street_lamp_double.glb`. Double street lamp
- `city_street_lamp_single.glb`. Single street lamp
- `city_trash_bin_round.glb`. Round trash bin
- `city_wood_metal_bench.glb`. Wood and metal bench

## collectibles
- `pickup_cash_bundle.glb`. Cash bundle
- `pickup_fuel_can.glb`. Fuel can
- `pickup_gold_coin.glb`. Gold coin
- `pickup_health_pack.glb`. Health pack
- `pickup_wanted_star.glb`. Wanted star

## decor
- `decor_blank_billboard.glb`. Blank billboard
- `decor_construction_pallet.glb`. Construction pallet
- `decor_fire_escape_platform.glb`. Fire escape platform
- `decor_graffiti_wall_section.glb`. Graffiti wall section
- `decor_helipad_marker.glb`. Helipad marker
- `decor_manhole_cover.glb`. Manhole cover
- `decor_metal_ladder.glb`. Metal ladder
- `decor_neon_arrow_sign.glb`. Neon arrow sign
- `decor_outdoor_table_chairs.glb`. Outdoor table and chairs
- `decor_rooftop_antenna.glb`. Rooftop antenna
- `decor_security_camera.glb`. Security camera
- `decor_sewer_grate.glb`. Sewer grate
- `decor_shipping_container_blue.glb`. Blue shipping container
- `decor_shopping_cart.glb`. Shopping cart
- `decor_small_jump_ramp.glb`. Small jump ramp

## environment
- `env_chainlink_fence_section.glb`. Chainlink fence section
- `env_city_tree_autumn.glb`. Autumn city tree
- `env_city_tree_green.glb`. Green city tree
- `env_gray_rock_large.glb`. Large gray rock
- `env_gray_rock_small.glb`. Small gray rock
- `env_low_bush.glb`. Low bush
- `env_palm_tree_short.glb`. Short palm tree
- `env_palm_tree_tall.glb`. Tall palm tree
- `env_street_planter.glb`. Street planter
- `env_water_puddle.glb`. Water puddle
- `env_wooden_fence_section.glb`. Wooden fence section

## environment_tiles
- `env_curb_piece.glb`. Curb piece
- `env_grass_tile.glb`. Grass tile
- `env_sidewalk_tile.glb`. Sidewalk tile

## gameplay_props
- `prop_black_briefcase.glb`. Black briefcase
- `prop_dark_supply_crate.glb`. Dark supply crate
- `prop_keypad_door.glb`. Keypad security door
- `prop_money_bag.glb`. Money bag
- `prop_small_safe.glb`. Small safe
- `prop_wooden_loot_crate.glb`. Wooden loot crate

## road
- `road_arrow_sign.glb`. Arrow sign
- `road_city_traffic_light.glb`. City traffic light
- `road_concrete_barrier.glb`. Concrete road barrier
- `road_generic_barricade.glb`. Generic barricade
- `road_pedestrian_crossing_light.glb`. Pedestrian crossing light
- `road_plastic_water_barrier.glb`. Plastic water barrier
- `road_speed_sign.glb`. Speed sign
- `road_steel_barricade.glb`. Steel barricade
- `road_stop_sign.glb`. Stop sign
- `road_traffic_cone_blue.glb`. Blue traffic cone
- `road_traffic_cone_orange.glb`. Orange traffic cone
- `road_warning_sign.glb`. Warning sign

## road_tiles
- `road_tile_corner_lines.glb`. Corner road tile
- `road_tile_crosswalk.glb`. Crosswalk road tile
- `road_tile_lane_marking.glb`. Lane marking road tile
- `road_tile_plain.glb`. Plain road tile

## vehicles
- `vehicle_black_suv.glb`. Black SUV
- `vehicle_blue_sedan.glb`. Blue sedan
- `vehicle_compact_microcar.glb`. Compact microcar
- `vehicle_gray_hatchback.glb`. Gray hatchback
- `vehicle_green_pickup.glb`. Green pickup truck
- `vehicle_orange_muscle_car.glb`. Orange muscle car
- `vehicle_police_style_car.glb`. Generic patrol car
- `vehicle_purple_coupe.glb`. Purple coupe
- `vehicle_red_sports_car.glb`. Red sports car
- `vehicle_utility_truck.glb`. Utility truck
- `vehicle_white_delivery_van.glb`. White delivery van
- `vehicle_yellow_taxi.glb`. Yellow taxi
